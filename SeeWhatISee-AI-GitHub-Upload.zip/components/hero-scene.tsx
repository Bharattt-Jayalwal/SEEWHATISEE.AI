"use client";

import { Canvas, useFrame } from "@react-three/fiber";
import { useReducedMotion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

function OpticalCore({ still, simplified }: { still: boolean; simplified: boolean }) {
  const group = useRef<THREE.Group>(null);
  useFrame(({ pointer }, delta) => {
    if (!group.current || still) return;
    const targetY = THREE.MathUtils.clamp(pointer.x, -0.8, 0.8) * 0.2;
    const targetX = THREE.MathUtils.clamp(pointer.y, -0.65, 0.65) * 0.12;
    group.current.rotation.y = THREE.MathUtils.damp(group.current.rotation.y, targetY, 2, delta);
    group.current.rotation.x = THREE.MathUtils.damp(group.current.rotation.x, targetX, 2, delta);
    group.current.rotation.z += delta * 0.025;
  });

  return (
    <group ref={group}>
      <mesh rotation={[0.25, 0.2, -0.18]}>
        <torusGeometry args={[1.52, 0.035, 12, 128]} />
        <meshStandardMaterial color="#9de9e5" metalness={0.8} roughness={0.24} emissive="#1b726f" emissiveIntensity={0.32} />
      </mesh>
      <mesh rotation={[-0.35, 0.48, 0.12]}>
        <torusGeometry args={[1.22, 0.018, 8, 120]} />
        <meshStandardMaterial color="#b5aaff" metalness={0.78} roughness={0.3} emissive="#5144a5" emissiveIntensity={0.3} />
      </mesh>
      <mesh scale={[1.02, 1.02, 0.3]}>
        {simplified ? <sphereGeometry args={[1, 24, 16]} /> : <icosahedronGeometry args={[1, 3]} />}
        <meshPhysicalMaterial color="#a8dedc" metalness={0.12} roughness={0.14} transmission={simplified ? 0.54 : 0.82} thickness={0.6} ior={1.32} transparent opacity={0.7} />
      </mesh>
      {!simplified && <mesh position={[0, 0, 0.31]} scale={[0.6, 0.6, 0.15]}>
        <sphereGeometry args={[1, 48, 32]} />
        <meshPhysicalMaterial color="#c9bfff" roughness={0.18} metalness={0.2} transparent opacity={0.46} emissive="#57439c" emissiveIntensity={0.18} />
      </mesh>}
      <mesh position={[0, 0, 0.49]}>
        <ringGeometry args={[1.02, 1.045, 96]} />
        <meshBasicMaterial color="#d4f7f4" transparent opacity={0.62} />
      </mesh>
      <mesh position={[0, 0, 0.54]}>
        <circleGeometry args={[0.04, 24]} />
        <meshBasicMaterial color="#e3fffb" />
      </mesh>
    </group>
  );
}

export function HeroScene() {
  const reducedMotion = useReducedMotion();
  const [compact, setCompact] = useState(false);
  useEffect(() => {
    const media = window.matchMedia("(max-width: 620px)");
    const update = () => setCompact(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  return (
    <Canvas
      aria-label="A translucent optical lens representing visual understanding"
      camera={{ position: [0, 0, 5.8], fov: 36 }}
      dpr={reducedMotion || compact ? 1 : [1, 1.45]}
      fallback={<div aria-hidden="true" className="hero-canvas-fallback"><span className="fallback-lens" /></div>}
      frameloop={reducedMotion || compact ? "demand" : "always"}
      gl={{ alpha: true, antialias: true, powerPreference: "low-power" }}
    >
      <ambientLight intensity={1.2} />
      <pointLight position={[3.2, 2.6, 4]} color="#b6fbf4" intensity={4.3} distance={10} />
      <pointLight position={[-3.6, -2.3, -1]} color="#8875ee" intensity={3.3} distance={8} />
      <OpticalCore simplified={compact} still={Boolean(reducedMotion) || compact} />
    </Canvas>
  );
}
