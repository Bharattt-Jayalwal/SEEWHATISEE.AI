import Link from "next/link";

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link className={`brand${compact ? " brand--compact" : ""}`} href="/" aria-label="SeeWhatISee AI home">
      <svg aria-hidden="true" className="brand-mark" viewBox="0 0 34 34" fill="none">
        <path d="M4.5 17c3.35-5.1 7.5-7.65 12.5-7.65S26.15 11.9 29.5 17c-3.35 5.1-7.5 7.65-12.5 7.65S7.85 22.1 4.5 17Z" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="17" cy="17" r="4" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="17" cy="17" r="1.15" fill="currentColor" />
        <path d="M17 2.75v3M31.25 17h-3M17 28.25v3M5.75 17h-3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" opacity=".52" />
      </svg>
      {!compact && <span>SeeWhatISee<span className="brand-ai">AI</span></span>}
    </Link>
  );
}
