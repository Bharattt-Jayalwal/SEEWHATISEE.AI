"use client";

import Link from "next/link";
import Image from "next/image";
import {
  AlertCircle,
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  Camera,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronDown,
  CircleHelp,
  Copy,
  Eye,
  FileImage,
  Focus,
  ImagePlus,
  LoaderCircle,
  LockKeyhole,
  MessageCircle,
  Pause,
  Play,
  RotateCcw,
  Send,
  ShieldCheck,
  Square,
  StopCircle,
  Volume2,
  X,
} from "lucide-react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Brand } from "@/components/brand";
import type { ConversationTurn, Guidance, TaskState } from "@/lib/domain";
import { createInitialTask, reduceTaskState } from "@/lib/domain";
import { prepareImageUpload } from "@/lib/image-processing";

type Mode = "loading" | "demo" | "live";
type CameraState = "idle" | "starting" | "active" | "denied" | "unsupported" | "error";
type Frame = { dataUrl: string; name: string; capturedAt: Date; width: number; height: number };
type ChatMessage = { id: string; role: "user" | "assistant"; content: string; guidance?: Guidance; mode?: Mode };

function errorText(payload: unknown): string {
  if (payload && typeof payload === "object" && "error" in payload) {
    const error = payload.error;
    if (error && typeof error === "object" && "message" in error && typeof error.message === "string") return error.message;
  }
  return "Something went wrong. Please try again.";
}

function userFacingCameraError(error: unknown): { state: CameraState; message: string } {
  const name = error && typeof error === "object" && "name" in error ? String(error.name) : "";
  if (name === "NotAllowedError" || name === "SecurityError") {
    return { state: "denied", message: "Camera access was blocked. Allow camera access in your browser settings, or upload an image instead." };
  }
  if (name === "NotFoundError" || name === "OverconstrainedError") {
    return { state: "error", message: "No matching camera was found. Try another camera or upload an image." };
  }
  if (name === "NotReadableError") {
    return { state: "error", message: "The camera may be in use by another app. Close that app, or upload an image instead." };
  }
  return { state: "error", message: "The camera could not start. You can still upload an image to continue." };
}

function makeSessionSummary(task: TaskState): string {
  const confirmed = task.steps.filter((step) => step.completedByUser).map((step) => `- ${step.label}`).join("\n") || "- None confirmed";
  const unresolved = task.unresolvedQuestions.map((question) => `- ${question}`).join("\n") || "- None recorded";
  const actions = task.actionsDiscussed.map((action) => `- ${action}`).join("\n") || "- No questions asked yet";
  return [
    "SeeWhatISee AI — Session summary",
    `Objective: ${task.objective || "Not set"}`,
    "",
    "Actions discussed:", actions,
    "",
    "Steps you confirmed complete:", confirmed,
    "",
    "Unresolved questions:", unresolved,
    "",
    "Uncertainty:", task.uncertainty || "- None recorded",
    "",
    "Safety note:", task.safetyNote || "- None recorded",
    "",
    "Next suggested action:", task.nextAction,
  ].join("\n");
}

export function Workspace() {
  const reducedMotion = useReducedMotion();
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const cameraStartRef = useRef(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const liveAbortRef = useRef<AbortController | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const summaryDialogRef = useRef<HTMLElement>(null);
  const summaryTriggerRef = useRef<HTMLButtonElement>(null);
  const [mode, setMode] = useState<Mode>("loading");
  const [cameraState, setCameraState] = useState<CameraState>("idle");
  const [cameraMessage, setCameraMessage] = useState("");
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [cameraSize, setCameraSize] = useState({ width: 16, height: 9 });
  const [deviceId, setDeviceId] = useState("");
  const [frame, setFrame] = useState<Frame | null>(null);
  const [preparingUpload, setPreparingUpload] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [task, setTask] = useState<TaskState>(() => createInitialTask());
  const [taskPanelOpen, setTaskPanelOpen] = useState(true);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeGuidance, setActiveGuidance] = useState<Guidance | null>(null);
  const [walkthroughStep, setWalkthroughStep] = useState(0);
  const [walkthroughPlaying, setWalkthroughPlaying] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [liveGuide, setLiveGuide] = useState(false);
  const [liveStatus, setLiveStatus] = useState<"idle" | "analyzing" | "watching" | "error">("idle");
  const [draft, setDraft] = useState("");
  const [pending, setPending] = useState(false);
  const [pendingQuestion, setPendingQuestion] = useState("");
  const [sessionEnded, setSessionEnded] = useState(false);
  const [requestError, setRequestError] = useState("");
  const [retryQuestion, setRetryQuestion] = useState("");
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [notice, setNotice] = useState("");

  const currentStep = useMemo(
    () => task.steps.find((step) => !step.completedByUser)?.label ?? "All planned steps are confirmed",
    [task.steps],
  );
  const liveContextRef = useRef({ task, currentStep, messages });
  useEffect(() => {
    liveContextRef.current = { task, currentStep, messages };
  }, [task, currentStep, messages]);
  const captureCurrentFrame = useCallback((): { dataUrl: string; width: number; height: number } | null => {
    const video = videoRef.current;
    if (!video || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || !video.videoWidth) {
      setCameraMessage("The camera is still warming up. Wait a moment and try again.");
      return null;
    }
    const scale = Math.min(1, 1600 / Math.max(video.videoWidth, video.videoHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
    canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) {
      setUploadError("This browser could not capture a frame. Try an image upload instead.");
      return null;
    }
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    return { dataUrl: canvas.toDataURL("image/jpeg", 0.82), width: canvas.width, height: canvas.height };
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/status", { cache: "no-store", signal: controller.signal })
      .then((response) => response.json())
      .then((data: { mode?: string }) => setMode(data.mode === "live" ? "live" : "demo"))
      .catch(() => setMode("demo"));
    return () => {
      controller.abort();
      abortRef.current?.abort();
      cameraStartRef.current += 1;
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView?.({ behavior: reducedMotion ? "auto" : "smooth", block: "end" });
  }, [messages, pending, reducedMotion]);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(""), 3000);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  useEffect(() => {
    const stepCount = activeGuidance?.steps?.length ?? 0;
    if (!walkthroughPlaying || stepCount < 2) return;
    const interval = window.setInterval(() => {
      setWalkthroughStep((current) => {
        if (current >= stepCount - 1) {
          setWalkthroughPlaying(false);
          return current;
        }
        return current + 1;
      });
    }, 6000);
    return () => window.clearInterval(interval);
  }, [activeGuidance, walkthroughPlaying]);

  useEffect(() => {
    if (!voiceEnabled || !walkthroughPlaying || !activeGuidance?.steps?.length || !("speechSynthesis" in window)) return;
    const step = activeGuidance.steps[walkthroughStep];
    if (!step) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(`${step.title}. ${step.instruction}`);
    utterance.rate = 0.95;
    window.speechSynthesis.speak(utterance);
    return () => window.speechSynthesis.cancel();
  }, [activeGuidance, voiceEnabled, walkthroughPlaying, walkthroughStep]);

  useEffect(() => {
    if (!liveGuide || cameraState !== "active" || mode !== "live" || sessionEnded) return;
    let disposed = false;
    let busy = false;
    let activeController: AbortController | null = null;

    const analyzeCurrentView = async () => {
      if (disposed || busy) return;
      const captured = captureCurrentFrame();
      if (!captured) {
        setLiveStatus("error");
        return;
      }
      busy = true;
      const controller = new AbortController();
      activeController = controller;
      liveAbortRef.current = controller;
      setLiveStatus("analyzing");
      const context = liveContextRef.current;
      const question = context.task.actionsDiscussed.at(-1) || `Help me with: ${context.task.objective}`;
      const history: ConversationTurn[] = context.messages.slice(-6).map((message) => ({
        role: message.role,
        content: message.role === "user" ? message.content : message.guidance?.guidance ?? message.content,
      }));
      try {
        const response = await fetch("/api/analyze", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            imageData: captured.dataUrl,
            question,
            objective: context.task.objective,
            currentStep: context.currentStep,
            completedSteps: context.task.steps.filter((step) => step.completedByUser).map((step) => step.label),
            history,
          }),
        });
        const payload: unknown = await response.json();
        if (!response.ok) throw new Error(errorText(payload));
        if (disposed || controller.signal.aborted) return;
        const result = payload as { guidance?: Guidance };
        if (!result.guidance) throw new Error("The live response was incomplete.");
        setFrame({ ...captured, name: "Live camera frame", capturedAt: new Date() });
        setActiveGuidance(result.guidance);
        setWalkthroughStep(0);
        setTask((current) => reduceTaskState(current, { type: "record-guidance", guidance: result.guidance!, userQuestion: question }));
        setLiveStatus("watching");
      } catch (error) {
        if (disposed || controller.signal.aborted) return;
        setLiveStatus("error");
        setLiveGuide(false);
        setNotice(`Live guide paused: ${error instanceof Error ? error.message : "Analysis failed."}`);
      } finally {
        if (liveAbortRef.current === controller) liveAbortRef.current = null;
        if (activeController === controller) activeController = null;
        busy = false;
      }
    };

    void analyzeCurrentView();
    const interval = window.setInterval(() => void analyzeCurrentView(), 8000);
    return () => {
      disposed = true;
      window.clearInterval(interval);
      activeController?.abort();
      if (liveAbortRef.current === activeController) liveAbortRef.current = null;
    };
  }, [cameraState, captureCurrentFrame, liveGuide, mode, sessionEnded]);

  useEffect(() => {
    if (!summaryOpen) return;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const summaryTrigger = summaryTriggerRef.current;
    const firstFrame = window.requestAnimationFrame(() => {
      summaryDialogRef.current?.querySelector<HTMLElement>("button, a, input, textarea, [tabindex]:not([tabindex='-1'])")?.focus();
    });
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSummaryOpen(false);
        return;
      }
      if (event.key !== "Tab" || !summaryDialogRef.current) return;
      const controls = [...summaryDialogRef.current.querySelectorAll<HTMLElement>("button:not([disabled]), a[href], input:not([disabled]), textarea:not([disabled])")];
      if (!controls.length) return;
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      window.cancelAnimationFrame(firstFrame);
      window.removeEventListener("keydown", onKeyDown);
      if (previousFocus?.isConnected) previousFocus.focus();
      else summaryTrigger?.focus();
    };
  }, [summaryOpen]);

  const stopCamera = useCallback(() => {
    cameraStartRef.current += 1;
    liveAbortRef.current?.abort();
    liveAbortRef.current = null;
    setLiveGuide(false);
    setLiveStatus("idle");
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraState("idle");
    setDeviceId("");
  }, []);

  const startCamera = useCallback(async (preferredDeviceId?: string) => {
    const startId = ++cameraStartRef.current;
    setCameraMessage("");
    setCameraState("starting");
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraState("unsupported");
      setCameraMessage("This browser does not support camera access. Upload an image to continue.");
      return;
    }
    try {
      const video = preferredDeviceId
        ? { deviceId: { exact: preferredDeviceId }, width: { ideal: 1920 }, height: { ideal: 1080 } }
        : { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1080 } };
      const stream = await navigator.mediaDevices.getUserMedia({ video, audio: false });
      if (startId !== cameraStartRef.current) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      streamRef.current = stream;
      const track = stream.getVideoTracks()[0];
      const actualDeviceId = track?.getSettings().deviceId ?? preferredDeviceId ?? "";
      setDeviceId(actualDeviceId);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      if (startId !== cameraStartRef.current) {
        stream.getTracks().forEach((track) => track.stop());
        if (streamRef.current === stream) streamRef.current = null;
        return;
      }
      if (videoRef.current?.videoWidth && videoRef.current.videoHeight) {
        setCameraSize({ width: videoRef.current.videoWidth, height: videoRef.current.videoHeight });
      }
      setCameraState("active");
      const available = await navigator.mediaDevices.enumerateDevices();
      setDevices(available.filter((entry) => entry.kind === "videoinput"));
    } catch (error) {
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      const message = userFacingCameraError(error);
      setCameraState(message.state);
      setCameraMessage(message.message);
    }
  }, []);

  const switchCamera = useCallback(async () => {
    if (devices.length < 2) return;
    const currentIndex = Math.max(0, devices.findIndex((device) => device.deviceId === deviceId));
    const next = devices[(currentIndex + 1) % devices.length];
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setCameraState("starting");
    await startCamera(next.deviceId);
  }, [deviceId, devices, startCamera]);

  const captureFrame = useCallback(() => {
    const captured = captureCurrentFrame();
    if (!captured) return;
    setFrame({ ...captured, name: "Camera frame", capturedAt: new Date() });
    setActiveGuidance(null);
    setWalkthroughPlaying(false);
    setUploadError("");
    setRequestError("");
  }, [captureCurrentFrame]);

  const chooseFile = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = "";
    if (!file) return;
    setPreparingUpload(true);
    setUploadError("");
    try {
      const prepared = await prepareImageUpload(file);
      stopCamera();
      setFrame({ dataUrl: prepared.dataUrl, name: file.name, capturedAt: new Date(), width: prepared.width, height: prepared.height });
      setActiveGuidance(null);
      setWalkthroughPlaying(false);
      setRequestError("");
    } catch (error) {
      setUploadError(error instanceof Error ? error.message : "That image could not be processed.");
    } finally {
      setPreparingUpload(false);
    }
  }, [stopCamera]);

  const submitQuestion = useCallback(async (question: string) => {
    const normalizedQuestion = question.trim();
    if (!normalizedQuestion || pending || sessionEnded) return;
    if (mode === "live" && !frame) {
      setRequestError("Capture a frame or upload an image before asking for live analysis.");
      return;
    }
    const controller = new AbortController();
    abortRef.current?.abort();
    abortRef.current = controller;
    setPending(true);
    setPendingQuestion(normalizedQuestion);
    setRequestError("");
    setRetryQuestion("");
    try {
      const history: ConversationTurn[] = messages.slice(-6).map((message) => ({
        role: message.role,
        content: message.role === "user" ? message.content : message.guidance?.guidance ?? message.content,
      }));
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          ...(mode === "live" && frame ? { imageData: frame.dataUrl } : {}),
          question: normalizedQuestion,
          objective: task.objective,
          currentStep,
          completedSteps: task.steps.filter((step) => step.completedByUser).map((step) => step.label),
          history,
        }),
      });
      const payload: unknown = await response.json();
      if (!response.ok) throw new Error(errorText(payload));
      if (controller.signal.aborted) return;
      const result = payload as { mode?: Mode; guidance?: Guidance };
      if (!result.guidance) throw new Error("The response was incomplete. Please try again.");
      const responseMode: Mode = result.mode === "live" ? "live" : "demo";
      const assistantMessage: ChatMessage = {
        id: crypto.randomUUID(), role: "assistant", content: result.guidance.guidance,
        guidance: result.guidance, mode: responseMode,
      };
      setMessages((current) => [
        ...current,
        { id: crypto.randomUUID(), role: "user", content: normalizedQuestion },
        assistantMessage,
      ]);
      setActiveGuidance(result.guidance);
      setWalkthroughStep(0);
      setWalkthroughPlaying(false);
      setTask((current) => reduceTaskState(current, { type: "record-guidance", guidance: result.guidance!, userQuestion: normalizedQuestion }));
      setMode(responseMode);
      setDraft("");
      setRequestError("");
    } catch (error) {
      if (controller.signal.aborted) return;
      setRequestError(error instanceof Error ? error.message : "Analysis failed. Please try again.");
      setRetryQuestion(normalizedQuestion);
    } finally {
      if (abortRef.current === controller) abortRef.current = null;
      setPending(false);
      setPendingQuestion("");
    }
  }, [currentStep, frame, messages, mode, pending, sessionEnded, task]);

  const endSession = useCallback(() => {
    abortRef.current?.abort();
    liveAbortRef.current?.abort();
    liveAbortRef.current = null;
    setLiveGuide(false);
    setLiveStatus("idle");
    abortRef.current = null;
    cameraStartRef.current += 1;
    setPending(false);
    setPendingQuestion("");
    setRetryQuestion("");
    stopCamera();
    setFrame(null);
    setSessionEnded(true);
    setSummaryOpen(true);
    setNotice("Session ended. The camera is off.");
  }, [stopCamera]);

  const toggleLiveGuide = useCallback(() => {
    if (liveGuide) {
      liveAbortRef.current?.abort();
      liveAbortRef.current = null;
      setLiveGuide(false);
      setLiveStatus("idle");
      setNotice("Live guide paused. The camera is still on.");
      return;
    }
    setLiveStatus("analyzing");
    setLiveGuide(true);
    setNotice("Live guide started. Camera frames are checked every eight seconds.");
  }, [liveGuide]);

  const clearSession = useCallback(() => {
    abortRef.current?.abort();
    liveAbortRef.current?.abort();
    liveAbortRef.current = null;
    setLiveGuide(false);
    setLiveStatus("idle");
    abortRef.current = null;
    cameraStartRef.current += 1;
    setPending(false);
    setPendingQuestion("");
    stopCamera();
    setFrame(null);
    setMessages([]);
    setActiveGuidance(null);
    setWalkthroughStep(0);
    setWalkthroughPlaying(false);
    setTask(createInitialTask());
    setDraft("");
    setRequestError("");
    setRetryQuestion("");
    setUploadError("");
    setSessionEnded(false);
    setSummaryOpen(false);
    setNotice("Session cleared. The camera is off.");
  }, [stopCamera]);

  const summary = useMemo(() => makeSessionSummary(task), [task]);

  const copyText = useCallback(async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setNotice(`${label} copied.`);
    } catch {
      setNotice("Clipboard access is unavailable in this browser.");
    }
  }, []);

  const downloadSummary = useCallback(() => {
    const url = URL.createObjectURL(new Blob([summary], { type: "text/plain;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "seewhatisee-session-summary.txt";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  }, [summary]);

  const walkthroughSteps = activeGuidance?.steps ?? [];
  const currentGuideStep = walkthroughSteps[walkthroughStep];

  return (
    <div className="workspace-page">
      <header className="workspace-header">
        <div className="workspace-header-left"><Link aria-label="Back to home" className="back-link" href="/"><ArrowLeft size={17} /><span>Home</span></Link><span className="workspace-header-divider" /><Brand /></div>
        <div className="workspace-header-center"><span className={`mode-badge mode-badge--${mode}`}><i />{mode === "live" ? "LIVE ANALYSIS" : mode === "loading" ? "CHECKING MODE" : "DEMO MODE"}</span><span className="workspace-session-label">Visual workspace <span>·</span> Guided setup</span></div>
        <div className="workspace-header-right"><button className="workspace-summary-button" onClick={() => setSummaryOpen(true)} ref={summaryTriggerRef} type="button"><FileImage size={15} /> <span>Summary</span></button><button className="workspace-end-button" onClick={sessionEnded ? clearSession : endSession} type="button"><StopCircle size={15} /> <span>{sessionEnded ? "New session" : "End session"}</span></button></div>
      </header>

      <main className="workspace-shell">
        <div className="workspace-title-row">
          <div><div className="eyebrow"><span className="section-index">WORKSPACE /</span> YOUR VIEW, YOUR PACE</div><h1>Let’s figure this <span>out together.</span></h1></div>
          <div className="workspace-privacy"><LockKeyhole size={14} /><span>{mode === "demo" ? "Demo mode · frames stay in this browser" : mode === "live" ? "Frames sent only when you request analysis" : "Checking provider configuration"}</span></div>
        </div>

        {mode === "demo" && <div className="demo-banner" role="status"><SparkleIcon /><span><b>AI image analysis is not connected yet.</b> Add <code>OPENAI_API_KEY</code> in Vercel project settings, then redeploy to turn on real photo and live-camera guidance.</span><a href="https://vercel.com/guardrail3/see-what-i-see-ai-preview/settings/environment-variables" rel="noreferrer" target="_blank">Open Vercel settings <ArrowRight size={13} /></a><a href="/privacy">Privacy <ArrowRight size={13} /></a></div>}
        {sessionEnded && <div className="session-ended-banner" role="status"><CheckCircle2 size={14} /><span>This session has ended. The camera is off and new analysis is disabled.</span><button onClick={clearSession} type="button">Start a new session <ArrowRight size={13} /></button></div>}

        <div className="workspace-grid">
          <aside className="task-sidebar">
            <button aria-controls="task-sidebar-content" aria-expanded={taskPanelOpen} className="task-drawer-toggle" onClick={() => setTaskPanelOpen((open) => !open)} type="button"><span><b>Task progress</b><small>{task.steps.filter((step) => step.completedByUser).length} of {task.steps.length} confirmed</small></span><ChevronDown size={16} /></button>
            <div className={`task-sidebar-content${taskPanelOpen ? "" : " task-sidebar-content--collapsed"}`} id="task-sidebar-content">
            <section className="task-card">
              <div className="panel-label"><span>YOUR TASK</span><span className="panel-label-line" /></div>
              <label className="task-input-label" htmlFor="objective">What are you trying to solve?</label>
              <input disabled={sessionEnded} id="objective" maxLength={300} onChange={(event) => setTask((state) => reduceTaskState(state, { type: "set-objective", objective: event.target.value }))} value={task.objective} />
              <div className="task-progress"><div><span>YOUR PROGRESS</span><b>{task.steps.filter((step) => step.completedByUser).length}<i> / </i>{task.steps.length}</b></div><div className="progress-track"><span style={{ width: `${task.steps.filter((step) => step.completedByUser).length / task.steps.length * 100}%` }} /></div></div>
              <div className="task-step-list">
                {task.steps.map((step, index) => (
                  <button aria-pressed={step.completedByUser} className={`task-step${step.completedByUser ? " is-complete" : ""}`} disabled={sessionEnded} key={step.id} onClick={() => setTask((state) => reduceTaskState(state, { type: "toggle-step", id: step.id }))} type="button">
                    <span className="task-step-check">{step.completedByUser ? <Check size={13} /> : <i>{String(index + 1).padStart(2, "0")}</i>}</span><span>{step.label}</span><span className="task-step-state">{step.completedByUser ? "CONFIRMED" : "TO DO"}</span>
                  </button>
                ))}
              </div>
              <div className="confirm-note"><CircleHelp size={13} /><span>Only you can confirm a physical step as complete.</span></div>
            </section>
            <section className="next-step-card">
              <div className="panel-label"><span>NEXT SUGGESTED ACTION</span><span className="panel-label-line" /></div>
              <div className="next-step-content"><span className="next-step-arrow"><ArrowRight size={15} /></span><p>{task.nextAction}</p></div>
              {task.observations.length > 0 && <div className="task-observations"><span>VISUAL NOTES</span><ul>{task.observations.map((observation) => <li key={observation}>{observation}</li>)}</ul></div>}
              {task.uncertainty && <p className="uncertainty-note"><AlertCircle size={13} />{task.uncertainty}</p>}
              {task.safetyNote && <p className="task-safety-note"><ShieldCheck size={13} />{task.safetyNote}</p>}
              {task.unresolvedQuestions.map((question) => <p className="unresolved-note" key={question}>{question}</p>)}
            </section>
            <div className="sidebar-assurance"><ShieldCheck size={16} /><span>Use guidance for low-risk setup. If a step feels unsafe or unclear, pause and check the device manual.</span></div>
            </div>
          </aside>

          <section className="visual-panel" aria-label="Camera and image workspace">
            <div className="visual-panel-head">
              <div className="visual-panel-title"><span className="visual-title-icon"><Eye size={15} /></span><span><b>YOUR VIEW</b><small>{liveGuide ? liveStatus === "analyzing" ? "Live guide · checking this view" : "Live guide · updating every 8 seconds" : cameraState === "active" ? "Camera active · capture when ready" : frame ? "Selected frame · ready to analyze" : "Camera off · start when ready"}</small></span></div>
              <div aria-live="polite" className="visual-panel-status" role="status">{liveGuide ? <><i className="camera-live-dot" /> LIVE GUIDE {liveStatus === "analyzing" ? "· CHECKING" : "· ON"}</> : cameraState === "active" ? <><i className="camera-live-dot" /> CAMERA ON</> : frame ? <><CheckCircle2 size={13} /> FRAME READY</> : <><span className="camera-off-dot" /> CAMERA OFF</>}</div>
            </div>
            <div className={`visual-stage${cameraState === "active" ? " visual-stage--live" : ""}`}>
              {cameraState === "active" && <div className={`visual-media-frame${frame && !liveGuide ? " visual-media-frame--hidden" : ""}`} style={{ aspectRatio: `${cameraSize.width} / ${cameraSize.height}` }}><video aria-label="Live camera preview" className="preview-video is-visible" muted playsInline ref={videoRef} />{liveGuide && currentGuideStep?.target.visible && <div aria-label={`Visual target: ${currentGuideStep.target.label}`} className="guide-target" style={{ left: `${currentGuideStep.target.x}%`, top: `${currentGuideStep.target.y}%` }}><span>{String(walkthroughStep + 1).padStart(2, "0")}</span><b>{currentGuideStep.target.label}</b></div>}</div>}
              {frame && !liveGuide && <div className="visual-media-frame" style={{ aspectRatio: `${frame.width} / ${frame.height}` }}><Image alt={`Selected frame: ${frame.name}`} className="preview-image" fill sizes="(max-width: 760px) 100vw, 60vw" src={frame.dataUrl} unoptimized />{currentGuideStep?.target.visible && <div aria-label={`Visual target: ${currentGuideStep.target.label}`} className="guide-target" style={{ left: `${currentGuideStep.target.x}%`, top: `${currentGuideStep.target.y}%` }}><span>{String(walkthroughStep + 1).padStart(2, "0")}</span><b>{currentGuideStep.target.label}</b></div>}</div>}
              {!frame && cameraState !== "active" && (
                <div className="stage-empty">
                  <div className="stage-empty-lens"><span><Eye size={25} strokeWidth={1.25} /></span><i /><i /></div>
                  <div className="stage-empty-copy"><span>{cameraState === "starting" ? "CONNECTING TO CAMERA" : "YOUR CAMERA IS OFF"}</span><p>{cameraState === "starting" ? "Waiting for camera permission…" : "When you’re ready, start your camera or choose an image."}</p></div>
                  <div className="stage-empty-hint"><span>01</span><i /><span>FRAME</span></div>
                </div>
              )}
              {cameraState === "active" && !frame && <div className="viewfinder" aria-hidden="true"><i /><i /><i /><i /></div>}
              {frame && <div className="frame-caption"><span><Check size={12} /> SELECTED FRAME</span><span>{frame.name} · {frame.capturedAt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span></div>}
              {cameraState === "active" && <div className="camera-active-label"><i /> LIVE PREVIEW</div>}
            </div>
            {frame && currentGuideStep && <div className="walkthrough-panel" aria-live="polite">
              <div className="walkthrough-head"><span>VISUAL WALKTHROUGH</span><b>STEP {String(walkthroughStep + 1).padStart(2, "0")} / {String(walkthroughSteps.length).padStart(2, "0")}</b></div>
              <h3>{currentGuideStep.title}</h3><p>{currentGuideStep.instruction}</p>
              <div className="walkthrough-controls">
                <button aria-label="Previous step" className="walkthrough-icon-button" disabled={walkthroughStep === 0} onClick={() => { setWalkthroughPlaying(false); setWalkthroughStep((step) => Math.max(0, step - 1)); }} type="button"><ChevronLeft size={14} /></button>
                <button aria-label={walkthroughPlaying ? "Pause walkthrough" : "Play walkthrough"} className="walkthrough-play-button" disabled={walkthroughSteps.length < 2} onClick={() => { if (walkthroughStep >= walkthroughSteps.length - 1) setWalkthroughStep(0); setWalkthroughPlaying((playing) => !playing); }} type="button">{walkthroughPlaying ? <Pause size={13} /> : <Play size={13} />}<span>{walkthroughPlaying ? "Pause" : "Play steps"}</span></button>
                <button aria-label="Next step" className="walkthrough-icon-button" disabled={walkthroughStep >= walkthroughSteps.length - 1} onClick={() => { setWalkthroughPlaying(false); setWalkthroughStep((step) => Math.min(walkthroughSteps.length - 1, step + 1)); }} type="button"><ArrowRight size={13} /></button>
                <button aria-pressed={voiceEnabled} className={`walkthrough-voice-button${voiceEnabled ? " is-on" : ""}`} onClick={() => setVoiceEnabled((enabled) => !enabled)} type="button"><Volume2 size={13} /><span>{voiceEnabled ? "Narration on" : "Read aloud"}</span></button>
              </div>
            </div>}
            <div className="visual-controls">
              <div className="visual-control-group">
                {cameraState !== "active" ? (
                  <button className="button button--primary button--capture" disabled={sessionEnded || cameraState === "starting" || preparingUpload} onClick={() => void startCamera()} type="button">{cameraState === "starting" ? <LoaderCircle className="spin" size={16} /> : <Camera size={16} />}<span>{cameraState === "starting" ? "Starting camera" : "Start camera"}</span></button>
                ) : (
                  <button className="button button--primary button--capture" onClick={captureFrame} type="button"><Focus size={16} /><span>{frame ? "Retake frame" : "Capture frame"}</span></button>
                )}
                <input accept="image/jpeg,image/png,image/webp" className="visually-hidden" onChange={(event) => void chooseFile(event)} ref={fileInputRef} type="file" />
                <button className="button button--outline" disabled={sessionEnded || preparingUpload} onClick={() => fileInputRef.current?.click()} type="button">{preparingUpload ? <LoaderCircle className="spin" size={15} /> : <ImagePlus size={15} />}<span>{preparingUpload ? "Preparing" : "Upload image"}</span></button>
                {devices.length > 1 && cameraState === "active" && <button aria-label="Switch camera" className="icon-button camera-switch" onClick={() => void switchCamera()} title="Switch camera" type="button"><RotateCcw size={16} /></button>}
              </div>
              <div className="visual-stop-group">
                {cameraState === "active" && mode === "live" && <button aria-pressed={liveGuide} className={`live-guide-toggle${liveGuide ? " is-active" : ""}`} onClick={toggleLiveGuide} type="button">{liveGuide ? <Pause size={12} /> : <Play size={12} />}<span>{liveGuide ? "Pause live guide" : "Start live guide"}</span></button>}
                {cameraState === "active" && mode === "demo" && <span className="live-guide-locked" title="Add OPENAI_API_KEY in Vercel project settings to activate image analysis">Live guide needs AI setup</span>}
                {frame && <button className="retake-link" onClick={() => setFrame(null)} type="button"><X size={13} /> Remove frame</button>}
                {cameraState === "active" && <button className="stop-camera-button" onClick={stopCamera} type="button"><Square size={11} fill="currentColor" /> Stop camera</button>}
              </div>
            </div>
            {(cameraMessage || uploadError) && <div className="inline-error" role="alert"><AlertCircle size={15} /><span>{cameraMessage || uploadError}</span><button aria-label="Dismiss" onClick={() => { setCameraMessage(""); setUploadError(""); }} type="button"><X size={14} /></button></div>}
            <div className="visual-privacy-foot"><LockKeyhole size={12} /><span>{mode === "demo" ? "This demo does not send your selected frame." : liveGuide ? "Live guide sends one camera frame every 8 seconds until paused." : "Frames are sent when you submit a question. Live guide stays off until you start it."}</span><span className="frame-size-note">MAX 8 MB UPLOAD</span></div>
          </section>

          <section className="conversation-panel" aria-label="Guidance conversation">
            <div className="conversation-head"><div><span className="conversation-icon"><MessageCircle size={15} /></span><span><b>GUIDANCE</b><small>Ask, see the steps, keep going</small></span></div><button aria-label="Clear conversation" className="icon-button clear-chat-button" onClick={clearSession} title="Clear session" type="button"><RotateCcw size={14} /></button></div>
            <div aria-live="polite" aria-relevant="additions text" className="conversation-scroll" role="log">
              {messages.length === 0 && <div className="conversation-welcome"><div className="welcome-orb"><MessageCircle size={18} /></div><span>READY WHEN YOU ARE</span><p>{mode === "demo" ? "You can explore the workflow here. Demo replies are clearly labeled and don’t inspect your image." : mode === "live" ? "Capture a frame, ask your question, and we’ll take it one step at a time." : "Checking your analysis mode…"}</p>{mode === "demo" && <small>To try live visual analysis, configure OPENAI_API_KEY on the server.</small>}</div>}
              {messages.map((message) => (
                <motion.article className={`chat-message chat-message--${message.role}`} key={message.id} initial={reducedMotion ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.28 }}>
                  {message.role === "user" ? <><span className="chat-role-label">YOU ASKED</span><p>{message.content}</p></> : <>
                    <div className="assistant-heading"><span className="assistant-mark"><SparkleIcon /></span><span>{message.mode === "demo" ? "SAMPLE RESPONSE" : "SEEWHATISEE AI"}</span></div>
                    {message.guidance && <><h3>{message.guidance.headline}</h3><div className="observations"><span>WHAT I CAN SEE</span><ul>{message.guidance.observations.map((observation) => <li key={observation}>{observation}</li>)}</ul></div><p>{message.guidance.guidance}</p>{message.guidance.safetyNote && <div className="safety-note-inline"><ShieldCheck size={14} /><span>{message.guidance.safetyNote}</span></div>}</>}
                    <button className="copy-message" onClick={() => void copyText(message.guidance?.guidance ?? message.content, "Response")} type="button"><Copy size={12} /> Copy response</button>
                  </>}
                </motion.article>
              ))}
              <AnimatePresence>
                {pending && <motion.article className="chat-message chat-message--pending" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}><div className="assistant-heading"><span className="assistant-mark assistant-mark--loading"><LoaderCircle className="spin" size={14} /></span><span>{mode === "demo" ? "PREPARING SAMPLE" : "ANALYZING SELECTED FRAME"}</span></div><p>{pendingQuestion}</p><div className="analysis-progress"><i /><i /><i /><span>{mode === "demo" ? "Creating sample response" : "Looking at one frame"}</span></div><button className="cancel-analysis" onClick={() => abortRef.current?.abort()} type="button">Cancel</button></motion.article>}
              </AnimatePresence>
              {requestError && <div className="request-error" role="alert"><AlertCircle size={15} /><div><p>{requestError}</p>{retryQuestion && <button onClick={() => void submitQuestion(retryQuestion)} type="button">Retry <RotateCcw size={13} /></button>}</div></div>}
              <div ref={chatEndRef} />
            </div>
            <div className="conversation-suggestions"><span>TRY ASKING</span><button onClick={() => setDraft("What am I looking at?")} type="button">What am I looking at?</button><button onClick={() => setDraft("Show me the next safe step.")} type="button">Show me the next safe step.</button></div>
            <form className="composer" onSubmit={(event) => { event.preventDefault(); void submitQuestion(draft); }}>
              <label className="visually-hidden" htmlFor="question">Ask about your selected frame</label>
              <textarea disabled={sessionEnded} id="question" maxLength={500} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void submitQuestion(draft); } }} placeholder={sessionEnded ? "Start a new session to continue…" : mode === "demo" ? "Ask a sample question…" : "Ask what you see…"} rows={2} value={draft} />
              <div className="composer-bottom"><span>ENTER TO SEND <i /> SHIFT + ENTER FOR NEW LINE</span><button aria-label="Send question" className="send-button" disabled={!draft.trim() || pending || sessionEnded || mode === "loading"} type="submit"><Send size={15} /></button></div>
            </form>
            <div className="conversation-disclaimer"><ShieldCheck size={12} /><span>Guidance can be wrong. Verify before changing connections.</span></div>
          </section>
        </div>
      </main>

      <AnimatePresence>
        {summaryOpen && <motion.div className="dialog-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSummaryOpen(false)}>
          <motion.section aria-labelledby="summary-title" aria-modal="true" className="summary-dialog" initial={reducedMotion ? false : { opacity: 0, y: 14, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 10 }} onClick={(event) => event.stopPropagation()} ref={summaryDialogRef} role="dialog" transition={{ duration: 0.2 }}>
            <div className="summary-dialog-head"><span className="summary-dialog-icon"><FileImage size={18} /></span><div><span>SESSION NOTES</span><h2 id="summary-title">Your progress, at a glance.</h2></div><button aria-label="Close summary" className="icon-button" onClick={() => setSummaryOpen(false)} type="button"><X size={17} /></button></div>
            <div className="summary-content"><p><b>Objective</b>{task.objective || "Not set"}</p><div><b>Actions discussed</b>{task.actionsDiscussed.length ? <ul>{task.actionsDiscussed.map((action, index) => <li key={`${action}-${index}`}>{action}</li>)}</ul> : <span>No questions asked yet</span>}</div><div><b>Steps you confirmed</b>{task.steps.some((step) => step.completedByUser) ? <ul>{task.steps.filter((step) => step.completedByUser).map((step) => <li key={step.id}>{step.label}</li>)}</ul> : <span>No steps confirmed complete</span>}</div><div><b>Unresolved items</b>{task.unresolvedQuestions.length ? <ul>{task.unresolvedQuestions.map((question) => <li key={question}>{question}</li>)}</ul> : <span>None recorded</span>}</div>{task.uncertainty && <p><b>Uncertainty</b>{task.uncertainty}</p>}{task.safetyNote && <p><b>Safety note</b>{task.safetyNote}</p>}<p><b>Suggested next step</b>{task.nextAction}</p><small>Only steps you confirmed are included as complete. AI guidance may be wrong.</small></div>
            <div className="summary-actions">{sessionEnded && <button className="button button--outline" onClick={clearSession} type="button"><RotateCcw size={14} /> New session</button>}<button className="button button--outline" onClick={() => void copyText(summary, "Summary")} type="button"><Copy size={14} /> Copy summary</button><button className="button button--primary" onClick={downloadSummary} type="button"><ArrowDownToLine size={14} /> Download .txt</button></div>
          </motion.section>
        </motion.div>}
      </AnimatePresence>
      <AnimatePresence>{notice && <motion.div aria-live="polite" className="toast-notice" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}><CheckCircle2 size={15} />{notice}</motion.div>}</AnimatePresence>
    </div>
  );
}

function SparkleIcon() {
  return <span aria-hidden="true" className="sparkle-icon"><Eye size={15} /></span>;
}
