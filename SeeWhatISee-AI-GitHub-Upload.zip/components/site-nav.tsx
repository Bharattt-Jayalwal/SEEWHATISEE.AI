"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { Brand } from "./brand";

const links = [
  ["Product", "#product"],
  ["How it works", "#how-it-works"],
  ["Use cases", "#use-cases"],
  ["Safety", "#safety"],
  ["About", "#about"],
] as const;

export function SiteNav() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`site-header${scrolled ? " is-scrolled" : ""}`}>
      <div className="site-nav shell">
        <Brand />
        <nav aria-label="Main navigation" className={`nav-links${menuOpen ? " nav-links--open" : ""}`}>
          {links.map(([label, href]) => (
            <a href={href} key={label} onClick={() => setMenuOpen(false)}>{label}</a>
          ))}
          <Link className="nav-mobile-cta" href="/workspace" onClick={() => setMenuOpen(false)}>
            Try live vision <ArrowUpRight size={15} />
          </Link>
        </nav>
        <div className="nav-actions">
          <Link className="button button--small button--nav" href="/workspace">
            <span>Try live vision</span><ArrowUpRight size={15} strokeWidth={1.8} />
          </Link>
          <button
            aria-expanded={menuOpen}
            aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
            className="icon-button menu-toggle"
            onClick={() => setMenuOpen((open) => !open)}
            type="button"
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>
    </header>
  );
}
