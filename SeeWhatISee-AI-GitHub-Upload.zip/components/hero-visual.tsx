"use client";

import dynamic from "next/dynamic";
import { Aperture, ScanLine, Sparkles } from "lucide-react";

const Scene = dynamic(() => import("./hero-scene").then((module) => module.HeroScene), {
  ssr: false,
  loading: () => <div aria-hidden="true" className="hero-canvas-fallback"><span className="fallback-lens" /></div>,
});

export function HeroVisual() {
  return (
    <div className="hero-visual" aria-label="Preview of the SeeWhatISee visual guidance workspace">
      <div className="hero-visual-glow" />
      <div className="hero-orbit hero-orbit--one" />
      <div className="hero-orbit hero-orbit--two" />
      <div className="hero-canvas"><Scene /></div>
      <div className="hero-micro hero-micro--top"><span className="micro-square" /> camera stays off until you start</div>
      <div className="hero-micro hero-micro--bottom"><ScanLine size={13} /><span>One frame at a time</span></div>
      <div className="hero-tag hero-tag--observation">
        <span className="hero-tag-icon"><Aperture size={15} /></span>
        <span><small>VISUAL INPUT</small><b>Your selected frame</b></span>
      </div>
      <div className="hero-tag hero-tag--guidance">
        <span className="hero-tag-icon hero-tag-icon--violet"><Sparkles size={15} /></span>
        <span><small>CONTEXTUAL GUIDANCE</small><b>One clear next step</b></span>
      </div>
      <div className="hero-focus" aria-hidden="true"><i /><i /><i /><i /></div>
    </div>
  );
}
