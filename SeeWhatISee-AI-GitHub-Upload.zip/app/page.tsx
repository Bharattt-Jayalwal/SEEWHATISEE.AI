import Link from "next/link";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  CircleDot,
  Eye,
  FileImage,
  Fingerprint,
  Focus,
  ImagePlus,
  MonitorCog,
  Router,
  ShieldCheck,
  Sparkles,
  Waypoints,
} from "lucide-react";
import { Brand } from "@/components/brand";
import { HeroVisual } from "@/components/hero-visual";
import { Reveal } from "@/components/reveal";
import { SiteNav } from "@/components/site-nav";

const steps = [
  { number: "01", title: "Show what matters", text: "Start the camera when you’re ready, or upload a single image.", icon: Eye },
  { number: "02", title: "Ask in your own words", text: "Point us toward what you’re trying to understand or troubleshoot.", icon: Focus },
  { number: "03", title: "Get visual guidance", text: "Follow numbered steps, with a callout on the image when a target is clear.", icon: Waypoints },
  { number: "04", title: "Confirm your progress", text: "Mark a physical step complete only after you’ve done it.", icon: CheckCircle2 },
  { number: "05", title: "Review the result", text: "Copy or download a summary of what’s done and what remains.", icon: FileImage },
];

const useCases = [
  { number: "01", icon: MonitorCog, name: "Computer setup", line: "Connect a display, identify a port, or get peripherals in place.", note: "External connections only. No case opening or repair guidance." },
  { number: "02", icon: Router, name: "Router setup", line: "Find the right labeled port and understand a confusing indicator.", note: "Provider-specific credentials and network security stay yours." },
  { number: "03", icon: ImagePlus, name: "Unfamiliar equipment", line: "Learn what a visible button, cable, or control appears to do.", note: "The model will ask when a label or object is hard to distinguish." },
  { number: "04", icon: CircleDot, name: "Guided procedures", line: "Follow simple, documented steps and keep track as you go.", note: "You confirm each physical step yourself." },
];

export default function HomePage() {
  const contactEmail = process.env.NEXT_PUBLIC_CONTACT_EMAIL?.trim();
  return (
    <>
      <SiteNav />
      <main>
        <section className="hero shell" id="product">
          <div className="hero-copy">
            <Reveal>
              <div className="eyebrow"><span className="eyebrow-mark"><Sparkles size={13} /></span> VISUAL GUIDANCE FOR REAL LIFE <span className="eyebrow-divider" /> EARLY ACCESS</div>
              <h1>Your world.<br /><span>Understood.</span></h1>
              <p className="hero-lede">Show AI what you see. Get clear, contextual guidance for the task in front of you.</p>
              <div className="hero-actions">
                <Link className="button button--primary" href="/workspace">Try live vision <ArrowUpRight size={17} /></Link>
                <a className="text-link" href="#how-it-works">See how it works <ArrowDown size={15} /></a>
              </div>
              <div className="hero-status"><span className="status-indicator" /> <span>Camera off by default</span><i /> <span>Live guide is opt-in</span></div>
            </Reveal>
          </div>
          <Reveal className="hero-visual-wrap" delay={0.1}><HeroVisual /></Reveal>
          <div className="hero-index" aria-hidden="true"><span>01</span><i /><span>03</span></div>
          <a className="hero-scroll" href="#how-it-works"><span>SCROLL TO EXPLORE</span><span className="scroll-line" /></a>
        </section>

        <section className="signal-strip" aria-label="Product principles">
          <div className="shell signal-strip-inner">
            <span><span className="signal-dot" /> Practical visual problem solving</span>
            <span><Fingerprint size={15} /> You choose what to share</span>
            <span><ShieldCheck size={15} /> No background capture</span>
            <span className="signal-strip-note">A thoughtful first release, with room to grow.</span>
          </div>
        </section>

        <section className="section how-section shell" id="how-it-works">
          <Reveal className="section-heading-row">
            <div><div className="eyebrow"><span className="section-index">01 /</span> A CALMER WAY TO FIGURE IT OUT</div><h2>From “what am I looking at?”<br /><span>to “I’ve got this.”</span></h2></div>
            <p className="section-intro">A simple loop built around your view and your pace. The camera remains yours to control, throughout.</p>
          </Reveal>
          <div className="steps-grid">
            {steps.map(({ number, title, text, icon: Icon }, index) => (
              <Reveal className="step-card" delay={index * 0.08} key={number}>
                <div className="step-card-top"><span>{number}</span><Icon size={19} strokeWidth={1.5} /></div>
                <div className="step-connector"><i /></div>
                <h3>{title}</h3><p>{text}</p>
              </Reveal>
            ))}
          </div>
          <Reveal className="flow-note"><div className="flow-note-visual"><span className="flow-node">PHOTO</span><i /><span className="flow-node flow-node--ai"><Sparkles size={13} /> VISUAL STEPS</span><i /><span className="flow-node">LIVE FOLLOW-UP</span></div><p>Ask about a photo, then opt into live camera guidance if you want it.</p><Link href="/workspace">Enter the workspace <ArrowRight size={15} /></Link></Reveal>
        </section>

        <section className="usecase-section" id="use-cases">
          <div className="shell section">
            <Reveal className="section-heading-row">
              <div><div className="eyebrow"><span className="section-index">02 /</span> A FOCUSED FIRST STEP</div><h2>Small, practical wins<br /><span>start right here.</span></h2></div>
              <p className="section-intro">Ask about everyday objects, setup, learning, and low-risk troubleshooting. The assistant uses what is visible and asks when it cannot tell.</p>
            </Reveal>
            <div className="usecase-grid">
              {useCases.map(({ number, icon: Icon, name, line, note }, index) => (
                <Reveal className="usecase-card" key={number} delay={index % 2 * 0.07}>
                  <div className="usecase-meta"><span>{number}</span><Icon size={19} strokeWidth={1.45} /></div>
                  <h3>{name}</h3><p>{line}</p>
                  <div className="usecase-boundary"><Check size={13} /><span>{note}</span></div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section className="safety-section" id="safety">
          <div className="shell safety-grid">
            <Reveal className="safety-copy">
              <div className="eyebrow"><span className="section-index">03 /</span> CONTROL IS PART OF THE PRODUCT</div>
              <h2>Good help begins<br /><span>with clear boundaries.</span></h2>
              <p className="section-intro">You decide when the camera starts and what it sees. You decide when a frame is sent for analysis. You can stop the session any time.</p>
              <Link className="text-link" href="/privacy">Read how privacy works <ArrowUpRight size={15} /></Link>
            </Reveal>
            <Reveal className="privacy-panel" delay={0.1}>
              <div className="privacy-panel-head"><span className="privacy-icon"><ShieldCheck size={17} /></span><span><b>Your view stays yours.</b><small>Designed around deliberate sharing.</small></span><span className="privacy-state">IN YOUR CONTROL</span></div>
              <div className="privacy-row"><span className="privacy-row-number">01</span><div><b>Permission first</b><p>Camera access begins only after you press Start camera.</p></div><Check size={16} /></div>
              <div className="privacy-row"><span className="privacy-row-number">02</span><div><b>Capture when ready</b><p>A frame is analyzed only after you capture or upload it.</p></div><Check size={16} /></div>
              <div className="privacy-row"><span className="privacy-row-number">03</span><div><b>No frame storage by default</b><p>Selected frames are kept in browser memory for this session.</p></div><Check size={16} /></div>
              <div className="privacy-row"><span className="privacy-row-number">04</span><div><b>Clear limits</b><p>AI can be mistaken. It does not replace a technician or official manual.</p></div><Check size={16} /></div>
              <div className="privacy-panel-foot"><span><i /> CAMERA IDLE</span><span>READY WHEN YOU ARE</span></div>
            </Reveal>
          </div>
        </section>

        <section className="closing-section shell" id="about">
          <Reveal className="closing-card">
            <span className="closing-orbit closing-orbit--a" /><span className="closing-orbit closing-orbit--b" />
            <div className="closing-copy"><div className="eyebrow"><span className="eyebrow-mark"><Sparkles size={13} /></span> SEE IT. ASK. MOVE FORWARD.</div><h2>The next step<br /><span>is clearer now.</span></h2><p>Bring the task in front of you. Start with one question.</p><Link className="button button--primary" href="/workspace">Open your workspace <ArrowUpRight size={17} /></Link></div>
            <div className="closing-stamp" aria-hidden="true"><Eye size={47} strokeWidth={0.9} /><span>SEE WHAT<br />YOU SEE</span></div>
          </Reveal>
        </section>
      </main>
      <footer className="site-footer shell">
        <div className="footer-top"><div><Brand /><p>Visual guidance for the task in front of you.</p></div><div className="footer-links"><a href="#product">Product</a><a href="#how-it-works">How it works</a><a href="#use-cases">Use cases</a><a href="#safety">Safety</a><Link href="/privacy">Privacy</Link>{contactEmail ? <a href={`mailto:${contactEmail}`}>Contact</a> : null}</div><Link className="footer-cta" href="/workspace">Try the workspace <ArrowUpRight size={14} /></Link></div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} SeeWhatISee AI. Early access preview.</span><span>Images are sent to an external AI provider only when you request live analysis.</span></div>
      </footer>
    </>
  );
}
