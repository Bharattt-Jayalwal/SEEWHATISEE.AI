import type { Metadata } from "next";
import { Workspace } from "@/components/workspace";

export const metadata: Metadata = {
  title: "Visual Workspace — SeeWhatISee AI",
  description: "A camera-controlled workspace for visual setup guidance.",
};

export default function WorkspacePage() {
  return <Workspace />;
}
