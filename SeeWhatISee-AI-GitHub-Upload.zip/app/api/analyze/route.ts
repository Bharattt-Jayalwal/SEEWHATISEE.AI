import { NextResponse } from "next/server";
import { z } from "zod";
import { demoGuidance } from "@/lib/demo";
import { guidanceSchema } from "@/lib/domain";
import { validateImageDataUrl } from "@/lib/image-validation";
import { openAIProvider } from "@/lib/providers/openai";
import { takeRateLimitToken } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const requestSchema = z.object({
  imageData: z.string().max(4_300_000).optional(),
  question: z.string().trim().min(1).max(500),
  objective: z.string().trim().max(300).default(""),
  currentStep: z.string().trim().max(300).default(""),
  completedSteps: z.array(z.string().trim().max(120)).max(20).default([]),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().trim().min(1).max(1200),
      }),
    )
    .max(12)
    .default([]),
});

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json(
    { error: { code, message } },
    { status, headers: { "Cache-Control": "no-store" } },
  );
}

async function readJsonLimited(request: Request): Promise<{ body?: unknown; tooLarge: boolean }> {
  const reader = request.body?.getReader();
  if (!reader) return { tooLarge: false };
  const chunks: Uint8Array[] = [];
  let byteLength = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      byteLength += value.byteLength;
      if (byteLength > 4_500_000) {
        await reader.cancel();
        return { tooLarge: true };
      }
      chunks.push(value);
    }
  } catch {
    return { tooLarge: false };
  }
  const bytes = new Uint8Array(byteLength);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return { body: JSON.parse(new TextDecoder().decode(bytes)), tooLarge: false };
  } catch {
    return { tooLarge: false };
  }
}

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  const requestHost = request.headers.get("host") ?? new URL(request.url).host;
  if (origin) {
    try {
      if (new URL(origin).host !== requestHost) {
        return errorResponse(403, "origin_not_allowed", "This request could not be verified.");
      }
    } catch {
      return errorResponse(403, "origin_not_allowed", "This request could not be verified.");
    }
  }

  const length = Number(request.headers.get("content-length") ?? 0);
  if (length > 4_500_000) {
    return errorResponse(413, "request_too_large", "Choose an image smaller than 3 MB.");
  }

  const read = await readJsonLimited(request);
  if (read.tooLarge) return errorResponse(413, "request_too_large", "Choose an image smaller than 3 MB.");
  if (!read.body) return errorResponse(400, "invalid_json", "The request could not be read. Try again.");
  const result = requestSchema.safeParse(read.body);
  if (!result.success) {
    return errorResponse(400, "invalid_request", "Add a question of up to 500 characters and try again.");
  }

  // Demo responses use no image at all; selected frames stay in the browser until live analysis is configured.
  if (!process.env.OPENAI_API_KEY?.trim()) {
    return NextResponse.json(
      { mode: "demo", guidance: demoGuidance },
      { headers: { "Cache-Control": "no-store" } },
    );
  }

  if (!result.data.imageData || !validateImageDataUrl(result.data.imageData)) {
    return errorResponse(400, "invalid_image", "Capture or upload a valid JPEG, PNG, or WebP image first.");
  }

  const forwardedFor = request.headers.get("x-forwarded-for");
  const address = (request.headers.get("x-real-ip") ?? forwardedFor?.split(",")[0]?.trim() ?? "local").slice(0, 100);
  if (!takeRateLimitToken(address)) {
    return errorResponse(429, "rate_limited", "Too many requests. Wait a minute, then try again.");
  }

  try {
    const timeout = AbortSignal.timeout(30_000);
    const signal = AbortSignal.any([request.signal, timeout]);
    const guidance = guidanceSchema.parse(
      await openAIProvider.analyze(
        {
          ...result.data,
          imageData: result.data.imageData,
        },
        signal,
      ),
    );
    return NextResponse.json(
      { mode: "live", guidance },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    if (request.signal.aborted) return new Response(null, { status: 499 });
    const code = error instanceof Error ? error.message : "provider_unavailable";
    if (code === "invalid_image") {
      return errorResponse(400, "invalid_image", "The image data was not valid. Capture it again.");
    }
    if (code === "provider_rate_limit") {
      return errorResponse(429, "provider_rate_limit", "The AI service is busy. Wait a moment and retry.");
    }
    if (code === "provider_request_failed") {
      return errorResponse(502, "provider_request_failed", "The AI service could not process that request.");
    }
    if (code === "provider_invalid_response") {
      return errorResponse(502, "invalid_model_response", "The AI response was incomplete. Please retry.");
    }
    if (error instanceof Error && error.name === "TimeoutError") {
      return errorResponse(504, "provider_timeout", "Analysis took too long. Try again with a clearer frame.");
    }
    return errorResponse(503, "provider_unavailable", "Analysis is temporarily unavailable. Please retry.");
  }
}
