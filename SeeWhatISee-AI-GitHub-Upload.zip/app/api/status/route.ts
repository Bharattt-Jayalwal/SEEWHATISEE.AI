import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export function GET() {
  return NextResponse.json(
    { mode: process.env.OPENAI_API_KEY?.trim() ? "live" : "demo" },
    { headers: { "Cache-Control": "no-store" } },
  );
}
