import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SeeWhatISee AI — Your world. Understood.",
  description: "Show AI what you see. Get clear, contextual guidance for the task in front of you.",
  applicationName: "SeeWhatISee AI",
  openGraph: {
    title: "SeeWhatISee AI — Your world. Understood.",
    description: "Visual guidance for the task in front of you.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#090b10",
  colorScheme: "dark",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
