import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Check, LockKeyhole } from "lucide-react";
import { Brand } from "@/components/brand";

export const metadata: Metadata = {
  title: "Privacy and data flow — SeeWhatISee AI",
  description: "How SeeWhatISee AI handles camera permissions, selected images, and AI analysis.",
};

export const dynamic = "force-dynamic";

export default function PrivacyPage() {
  const liveMode = Boolean(process.env.OPENAI_API_KEY);
  return (
    <main className="privacy-page">
      <header className="privacy-page-header shell"><Link aria-label="Back to home" className="back-link" href="/"><ArrowLeft size={16} /> Home</Link><Brand /></header>
      <article className="privacy-document shell">
        <div className="eyebrow"><LockKeyhole size={13} /> DATA FLOW &amp; PERMISSIONS</div>
        <h1>Your view stays <span>in your control.</span></h1>
        <p className="privacy-lede">The camera starts only when you choose. A question sends one frame; the optional live guide sends a still frame every eight seconds only while you have turned it on. No continuous video stream is sent.</p>
        <div className={`privacy-mode-callout${liveMode ? " privacy-mode-callout--live" : ""}`}><span className="status-indicator" /><div><b>{liveMode ? "AI image analysis is configured on this server." : "This deployment is in demo mode."}</b><p>{liveMode ? "A submitted question sends its selected frame and text to the configured AI provider. Starting Live guide sends camera snapshots every eight seconds until you pause or stop it." : "The workspace uses a static sample answer. Selected images are not uploaded to the application server or an AI provider."}</p></div></div>
        <section><h2>Camera access</h2><p>The browser requests camera permission only after you press <b>Start camera</b>. The live preview is displayed in your browser. Press <b>Stop camera</b> or end the session to stop its media tracks. Camera availability depends on your browser and device permissions.</p></section>
        <section><h2>Frames and AI processing</h2><p>For photo questions, capture a frame or choose an image and submit a question. For live guidance, start the Live guide control in the workspace; the app then samples one still camera frame every eight seconds while the control is on. You can pause it at any time. The app resizes images in your browser before sending them.</p><p>In live mode, each request sends one still frame, a bounded amount of recent conversation text, and task context to the configured model provider. The app does not transmit a continuous video stream. Do not include personal, confidential, or sensitive information in a frame.</p></section>
        <section><h2>Storage and logs</h2><p>The application does not save captured or uploaded frames, create accounts, or keep session history on the server. Frames and conversation state are held in the active browser tab and disappear when you clear the session or close it. The app itself does not log request bodies or raw images.</p><p>The external model provider has its own data handling and retention terms. Review the provider’s current policies and configure an appropriate account before offering this product to other users.</p></section>
        <section><h2>Demo mode</h2><p>When <code>OPENAI_API_KEY</code> is not configured, the product labels the experience as Demo mode. The sample guidance is static and does not inspect the selected frame. Demo requests contain text only; the selected frame stays in your browser.</p></section>
        <section><h2>Limits and safety</h2><p>Visual guidance can be incomplete or wrong. It is intended for everyday, low-risk questions about objects, setup, learning, and troubleshooting. It does not guide dangerous electrical work, exposed wiring, hazardous chemicals, emergency response, or dangerous disassembly. The app cannot safely make medical, legal, or financial decisions from an image. Confirm physical steps yourself and consult a qualified professional when the task is uncertain or high-risk.</p></section>
        <div className="privacy-document-foot"><Check size={15} /><span>Last updated October 20, 2026 · Early access product behavior may change as the implementation evolves.</span></div>
        <Link className="button button--outline" href="/workspace">Return to the workspace <ArrowLeft className="arrow-left-rotate" size={14} /></Link>
      </article>
    </main>
  );
}
