type WindowEntry = { startedAt: number; count: number };

const windows = new Map<string, WindowEntry>();
const WINDOW_MS = 60_000;
const MAX_REQUESTS = 12;
let operations = 0;

export function takeRateLimitToken(key: string, now = Date.now()): boolean {
  operations += 1;
  if (operations % 256 === 0) {
    for (const [entryKey, entry] of windows) {
      if (now - entry.startedAt >= WINDOW_MS) windows.delete(entryKey);
    }
  }
  const existing = windows.get(key);
  if (!existing || now - existing.startedAt >= WINDOW_MS) {
    windows.set(key, { startedAt: now, count: 1 });
    return true;
  }
  if (existing.count >= MAX_REQUESTS) return false;
  existing.count += 1;
  return true;
}

export function resetRateLimitForTests() {
  windows.clear();
}

