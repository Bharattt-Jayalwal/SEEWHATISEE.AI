import type { Guidance } from "./domain";

export const demoGuidance: Guidance = {
  headline: "A guided answer, one step at a time",
  observations: ["Sample response. This demo did not inspect your camera or uploaded image."],
  guidance:
    "For a monitor connection, compare the labels beside the ports on the computer and display. A matching HDMI label is a useful clue, but check the device manuals if the labels are missing.",
  steps: [
    { title: "Find the port label", instruction: "Look beside the visible ports for a label such as HDMI or DisplayPort. Do not plug anything in until the label is clear.", target: { visible: false, label: "", x: 50, y: 50 } },
    { title: "Match both ends", instruction: "Check that the same connector type is available on the monitor and computer, then compare with the manuals.", target: { visible: false, label: "", x: 50, y: 50 } },
  ],
  nextAction: "When you are ready, show a clear view of both devices and ask about a specific connection.",
  needsClarification: false,
  unresolvedQuestion: "",
  uncertainty: "This example is static. Add an API key to get guidance based on the selected frame.",
  safetyNote: "Keep the setup to normal external connections. Do not open powered equipment or handle exposed wiring.",
};

