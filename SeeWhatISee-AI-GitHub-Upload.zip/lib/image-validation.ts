export const MAX_IMAGE_BYTES = 3 * 1024 * 1024;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"] as const;

export type ValidatedImage = { mimeType: (typeof ACCEPTED_IMAGE_TYPES)[number]; base64: string };

export function validateImageDataUrl(value: unknown): ValidatedImage | null {
  if (typeof value !== "string") return null;
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
  if (!match) return null;

  const mimeType = match[1] as ValidatedImage["mimeType"];
  const base64 = match[2];
  if (base64.length > Math.ceil(MAX_IMAGE_BYTES / 3) * 4 + 4) return null;
  const bytes = Buffer.from(base64, "base64");
  if (bytes.length === 0 || bytes.length > MAX_IMAGE_BYTES) return null;
  // Reject malformed/non-canonical base64 rather than letting Buffer silently ignore characters.
  if (bytes.toString("base64").replace(/=+$/, "") !== base64.replace(/=+$/, "")) return null;

  const isJpeg = bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  const isPng = bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  const isWebp =
    bytes.subarray(0, 4).toString("ascii") === "RIFF" &&
    bytes.subarray(8, 12).toString("ascii") === "WEBP";
  const signatureMatches =
    (mimeType === "image/jpeg" && isJpeg) ||
    (mimeType === "image/png" && isPng) ||
    (mimeType === "image/webp" && isWebp);

  return signatureMatches ? { mimeType, base64 } : null;
}

