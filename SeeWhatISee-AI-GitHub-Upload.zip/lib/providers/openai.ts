import "server-only";
import { guidanceSchema, type Guidance } from "../domain";
import { validateImageDataUrl } from "../image-validation";
import type { AnalyzeInput, VisionProvider } from "./types";

const modelOutputSchema = {
  type: "object",
  additionalProperties: false,
  required: [
    "headline",
    "observations",
    "guidance",
    "steps",
    "nextAction",
    "needsClarification",
    "unresolvedQuestion",
    "uncertainty",
    "safetyNote",
  ],
  properties: {
    headline: { type: "string" },
    observations: { type: "array", items: { type: "string" } },
    guidance: { type: "string" },
    steps: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["title", "instruction", "target"],
        properties: {
          title: { type: "string" },
          instruction: { type: "string" },
          target: {
            type: "object",
            additionalProperties: false,
            required: ["visible", "label", "x", "y"],
            properties: {
              visible: { type: "boolean" },
              label: { type: "string" },
              x: { type: "number", minimum: 0, maximum: 100 },
              y: { type: "number", minimum: 0, maximum: 100 },
            },
          },
        },
      },
    },
    nextAction: { type: "string" },
    needsClarification: { type: "boolean" },
    unresolvedQuestion: { type: "string" },
    uncertainty: { type: "string" },
    safetyNote: { type: "string" },
  },
} as const;

const safetyInstructions = `You are SeeWhatISee AI, a careful visual problem-solving assistant. Help with ordinary, low-risk questions about objects, setup, learning, and troubleshooting using only evidence in the user-provided image. Separate visible observations from assumptions. Ask a short clarifying question when the image is unclear. Give a short sequence of practical steps, one action at a time, and describe what the user should look for next. Never mark a physical step complete; only the user can confirm it.
Refuse instructions for dangerous electrical work, exposed wiring, weapons, hazardous chemicals, dangerous disassembly, emergency response, or other high-risk repairs. For medical, legal, or financial decisions, explain that the image is not enough to safely decide and direct the user to a qualified professional. Never fabricate locations, labels, coordinates, or certainty. For each visual step, set target.visible to true only when the exact target is clearly visible in the image; coordinates x and y are percentages from the top-left of the image. Otherwise set visible=false, label="", and coordinates to 50,50. Return concise, plain-language guidance in the requested JSON schema.`;

export async function analyzeWithOpenAI(
  input: AnalyzeInput,
  signal: AbortSignal,
): Promise<Guidance> {
  const image = validateImageDataUrl(input.imageData);
  if (!image) throw new Error("invalid_image");

  const apiKey = process.env.OPENAI_API_KEY?.trim();
  if (!apiKey) throw new Error("provider_not_configured");

  const history = input.history.slice(-6).map((turn) => ({
    role: turn.role,
    content: [{ type: "input_text", text: turn.content }],
  }));
  const context = [
    `User objective: ${input.objective || "not specified"}`,
    `Current step: ${input.currentStep || "not specified"}`,
    `Steps the user explicitly confirmed complete: ${input.completedSteps.join(", ") || "none"}`,
    `Question: ${input.question}`,
  ].join("\n");

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    signal,
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      store: false,
      max_output_tokens: 700,
      instructions: safetyInstructions,
      input: [
        ...history,
        {
          role: "user",
          content: [
            { type: "input_text", text: context },
            {
              type: "input_image",
              image_url: `data:${image.mimeType};base64,${image.base64}`,
              detail: "high",
            },
          ],
        },
      ],
      text: {
        format: {
          type: "json_schema",
          name: "visual_guidance",
          strict: true,
          schema: modelOutputSchema,
        },
      },
    }),
  });

  if (!response.ok) {
    const status = response.status;
    if (status === 429) throw new Error("provider_rate_limit");
    throw new Error(status >= 500 ? "provider_unavailable" : "provider_request_failed");
  }

  const body: unknown = await response.json();
  if (!body || typeof body !== "object" || !("output_text" in body)) {
    throw new Error("provider_invalid_response");
  }
  const outputText = (body as { output_text?: unknown }).output_text;
  if (typeof outputText !== "string") throw new Error("provider_invalid_response");

  try {
    return guidanceSchema.parse(JSON.parse(outputText));
  } catch {
    throw new Error("provider_invalid_response");
  }
}

export const openAIProvider: VisionProvider = { analyze: analyzeWithOpenAI };
