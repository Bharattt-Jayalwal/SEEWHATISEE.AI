import type { ConversationTurn, Guidance } from "../domain";

export type AnalyzeInput = {
  imageData: string;
  question: string;
  objective: string;
  currentStep: string;
  completedSteps: string[];
  history: ConversationTurn[];
};

export interface VisionProvider {
  analyze(input: AnalyzeInput, signal: AbortSignal): Promise<Guidance>;
}
