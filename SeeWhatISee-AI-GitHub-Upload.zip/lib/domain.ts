import { z } from "zod";

const visualStepSchema = z.object({
  title: z.string().min(1).max(100),
  instruction: z.string().min(1).max(320),
  target: z.object({
    visible: z.boolean(),
    label: z.string().max(80),
    x: z.number().min(0).max(100),
    y: z.number().min(0).max(100),
  }),
});

export const guidanceSchema = z.object({
  headline: z.string().min(1).max(120),
  observations: z.array(z.string().min(1).max(280)).max(5),
  guidance: z.string().min(1).max(1200),
  steps: z.array(visualStepSchema).max(5).default([]),
  nextAction: z.string().min(1).max(280),
  needsClarification: z.boolean(),
  unresolvedQuestion: z.string().max(280),
  uncertainty: z.string().max(500),
  safetyNote: z.string().max(500),
});

export type Guidance = z.input<typeof guidanceSchema>;

export type ConversationTurn = {
  role: "user" | "assistant";
  content: string;
};

export type SessionStep = {
  id: string;
  label: string;
  completedByUser: boolean;
};

export type TaskState = {
  objective: string;
  steps: SessionStep[];
  observations: string[];
  unresolvedQuestions: string[];
  nextAction: string;
  uncertainty: string;
  safetyNote: string;
  actionsDiscussed: string[];
};

export type TaskAction =
  | { type: "set-objective"; objective: string }
  | { type: "toggle-step"; id: string }
  | { type: "record-guidance"; guidance: Guidance; userQuestion: string };

export function createInitialTask(objective = "What would you like help with?"): TaskState {
  return {
    objective,
    steps: [
      { id: "identify", label: "Understand what is visible", completedByUser: false },
      { id: "connect", label: "Try the first safe step", completedByUser: false },
      { id: "configure", label: "Check what changed", completedByUser: false },
      { id: "verify", label: "Confirm the result", completedByUser: false },
    ],
    observations: [],
    unresolvedQuestions: [],
    nextAction: "Capture a clear view of the object, screen, or situation.",
    uncertainty: "",
    safetyNote: "",
    actionsDiscussed: [],
  };
}

export function reduceTaskState(state: TaskState, action: TaskAction): TaskState {
  switch (action.type) {
    case "set-objective":
      return { ...state, objective: action.objective };
    case "toggle-step":
      return {
        ...state,
        steps: state.steps.map((step) =>
          step.id === action.id
            ? { ...step, completedByUser: !step.completedByUser }
            : step,
        ),
      };
    case "record-guidance":
      return {
        ...state,
        observations: action.guidance.observations,
        unresolvedQuestions: action.guidance.needsClarification
          ? [action.guidance.unresolvedQuestion || "More detail is needed to identify this safely."]
          : [],
        nextAction: action.guidance.nextAction,
        uncertainty: action.guidance.uncertainty,
        safetyNote: action.guidance.safetyNote,
        actionsDiscussed: [...state.actionsDiscussed, action.userQuestion].slice(-12),
      };
  }
}

