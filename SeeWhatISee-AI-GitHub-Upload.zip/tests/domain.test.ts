import { describe, expect, it } from "vitest";
import { createInitialTask, reduceTaskState, type Guidance } from "@/lib/domain";

const guidance: Guidance = {
  headline: "The connector label is hard to read",
  observations: ["A dark port is visible near the edge of the device."],
  guidance: "Check the label next to that port before connecting anything.",
  nextAction: "Capture a closer view of the port label.",
  needsClarification: true,
  unresolvedQuestion: "Can you read the label beside the port?",
  uncertainty: "The frame is not clear enough to identify the connector.",
  safetyNote: "Do not open the computer case.",
};

describe("task state", () => {
  it("starts with no physically completed steps", () => {
    const state = createInitialTask();
    expect(state.steps).toHaveLength(4);
    expect(state.steps.every((step) => !step.completedByUser)).toBe(true);
  });

  it("records AI guidance without completing a physical step", () => {
    const initial = createInitialTask("Connect a monitor");
    const state = reduceTaskState(initial, { type: "record-guidance", guidance, userQuestion: "Which port is this?" });
    expect(state.objective).toBe("Connect a monitor");
    expect(state.steps.every((step) => !step.completedByUser)).toBe(true);
    expect(state.observations).toEqual(guidance.observations);
    expect(state.unresolvedQuestions).toEqual([guidance.unresolvedQuestion]);
    expect(state.actionsDiscussed).toEqual(["Which port is this?"]);
    expect(state.nextAction).toBe(guidance.nextAction);
  });

  it("changes completion only after an explicit user action", () => {
    const state = reduceTaskState(createInitialTask(), { type: "toggle-step", id: "identify" });
    expect(state.steps.find((step) => step.id === "identify")?.completedByUser).toBe(true);
    expect(state.steps.filter((step) => step.completedByUser)).toHaveLength(1);
  });

  it("clears stale unresolved questions after a response no longer needs clarification", () => {
    const previous = reduceTaskState(createInitialTask(), { type: "record-guidance", guidance, userQuestion: "Which port is this?" });
    const answered = { ...guidance, needsClarification: false, unresolvedQuestion: "", uncertainty: "" };
    const next = reduceTaskState(previous, { type: "record-guidance", guidance: answered, userQuestion: "Here is a closer view." });
    expect(next.unresolvedQuestions).toEqual([]);
    expect(next.uncertainty).toBe("");
    expect(next.actionsDiscussed).toHaveLength(2);
  });
});
