import { describe, expect, it } from "vitest";
import { validateImageDataUrl } from "@/lib/image-validation";
import { MAX_UPLOAD_BYTES, prepareImageUpload, sniffImageType } from "@/lib/image-processing";

const jpegBytes = Uint8Array.from([0xff, 0xd8, 0xff, 0x01, 0x02]);
const pngBytes = Uint8Array.from([137, 80, 78, 71, 13, 10, 26, 10, 0]);

describe("image validation", () => {
  it("accepts a base64 JPEG when the bytes match its declared type", () => {
    const result = validateImageDataUrl(`data:image/jpeg;base64,${Buffer.from(jpegBytes).toString("base64")}`);
    expect(result?.mimeType).toBe("image/jpeg");
  });

  it("rejects an extension or MIME type that does not match the file bytes", () => {
    expect(validateImageDataUrl(`data:image/png;base64,${Buffer.from(jpegBytes).toString("base64")}`)).toBeNull();
    expect(sniffImageType(jpegBytes)).toBe("image/jpeg");
  });

  it("rejects empty, malformed, and unapproved data URLs", () => {
    expect(validateImageDataUrl("")).toBeNull();
    expect(validateImageDataUrl("data:image/gif;base64,R0lGODlh")).toBeNull();
    expect(validateImageDataUrl("data:image/png;base64,not!base64")).toBeNull();
  });

  it("recognizes PNG signatures without trusting a filename", () => {
    expect(sniffImageType(pngBytes)).toBe("image/png");
    expect(sniffImageType(Uint8Array.from([0, 1, 2]))).toBeNull();
  });

  it("rejects a renamed text file before trying to decode it", async () => {
    const file = new File(["not an image"], "device.png", { type: "image/png" });
    await expect(prepareImageUpload(file)).rejects.toThrow("Choose a JPEG, PNG, or WebP image.");
  });

  it("rejects empty and oversized uploads", async () => {
    await expect(prepareImageUpload(new File([], "empty.jpg"))).rejects.toThrow("empty");
    const largeFile = new File([new Uint8Array(MAX_UPLOAD_BYTES + 1)], "large.jpg");
    await expect(prepareImageUpload(largeFile)).rejects.toThrow("over 8 MB");
  });
});
