import { afterEach, describe, expect, it } from "vitest";
import { resetRateLimitForTests, takeRateLimitToken } from "@/lib/rate-limit";

afterEach(() => resetRateLimitForTests());

describe("in-process request limit", () => {
  it("allows twelve requests in a window and rejects the next", () => {
    for (let index = 0; index < 12; index += 1) expect(takeRateLimitToken("client", 1000)).toBe(true);
    expect(takeRateLimitToken("client", 1000)).toBe(false);
  });

  it("starts a fresh window after sixty seconds", () => {
    for (let index = 0; index < 12; index += 1) takeRateLimitToken("client", 1000);
    expect(takeRateLimitToken("client", 61_001)).toBe(true);
  });

  it("keeps different client keys in separate windows", () => {
    for (let index = 0; index < 12; index += 1) takeRateLimitToken("one", 1000);
    expect(takeRateLimitToken("two", 1000)).toBe(true);
  });
});
