/** @vitest-environment jsdom */
import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Workspace } from "@/components/workspace";

vi.mock("next/link", async () => {
  const React = await import("react");
  return {
    default: ({ href, children, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement> & { href: string }) =>
      React.createElement("a", { href, ...props }, children),
  };
});

vi.mock("motion/react", async () => {
  const React = await import("react");
  type Props = React.HTMLAttributes<HTMLElement> & { initial?: unknown; animate?: unknown; exit?: unknown; transition?: unknown; viewport?: unknown; whileInView?: unknown };
  const motionProps = ["initial", "animate", "exit", "transition", "viewport", "whileInView"];
  const makeMotionTag = (tag: string) => {
    const component = React.forwardRef<HTMLElement, Props>((props, ref) => {
      const domProps: Record<string, unknown> = { ...props };
      motionProps.forEach((key) => delete domProps[key]);
      return React.createElement(tag, { ...domProps, ref }, props.children);
    });
    component.displayName = `Motion.${tag}`;
    return component;
  };
  const motion = new Proxy({}, { get: (_target, key) => makeMotionTag(String(key)) });
  return {
    motion,
    AnimatePresence: ({ children }: { children: React.ReactNode }) => React.createElement(React.Fragment, null, children),
    useReducedMotion: () => true,
  };
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  Object.defineProperty(navigator, "mediaDevices", { configurable: true, value: undefined });
});

function mockFetch(analyze: () => Promise<unknown> = async () => ({ mode: "demo", guidance: {
  headline: "Sample guidance",
  observations: ["This is a sample only."],
  guidance: "This demo response did not inspect your frame.",
  nextAction: "Add a provider key for live analysis.",
  needsClarification: false,
  unresolvedQuestion: "",
  uncertainty: "Static sample response.",
  safetyNote: "Use low-risk setup guidance only.",
} })) {
  vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    if (String(input).includes("/api/status")) return { json: async () => ({ mode: "demo" }) };
    const result = await analyze();
    return { ok: true, status: 200, json: async () => result, requestSignal: init?.signal };
  }));
}

function installCamera(getUserMedia: ReturnType<typeof vi.fn>) {
  const track = { stop: vi.fn(), getSettings: () => ({ deviceId: "camera-1" }) };
  const stream = { getTracks: () => [track], getVideoTracks: () => [track] };
  Object.defineProperty(navigator, "mediaDevices", {
    configurable: true,
    value: { getUserMedia, enumerateDevices: vi.fn(async () => [{ kind: "videoinput", deviceId: "camera-1", label: "Camera" }]) },
  });
  Object.defineProperty(HTMLMediaElement.prototype, "play", { configurable: true, value: vi.fn(async () => undefined) });
  getUserMedia.mockResolvedValue(stream);
  return { stream, track };
}

describe("visual workspace interactions", () => {
  it("does not request camera permission until the user starts it, and releases tracks on stop", async () => {
    mockFetch();
    const getUserMedia = vi.fn();
    const { track } = installCamera(getUserMedia);
    render(<Workspace />);
    await screen.findByText("Demo mode is active.");
    expect(getUserMedia).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole("button", { name: "Start camera" }));
    await screen.findByRole("button", { name: "Capture frame" });
    expect(getUserMedia).toHaveBeenCalledTimes(1);
    fireEvent.click(screen.getByRole("button", { name: /Stop camera/i }));
    await screen.findByText("CAMERA OFF");
    expect(track.stop).toHaveBeenCalledTimes(1);
  });

  it("explains denied camera permission and leaves image upload available", async () => {
    mockFetch();
    const denied = vi.fn();
    installCamera(denied);
    denied.mockRejectedValue(new DOMException("Permission denied", "NotAllowedError"));
    render(<Workspace />);
    fireEvent.click(screen.getByRole("button", { name: "Start camera" }));
    expect(await screen.findByText(/Camera access was blocked/)).toBeTruthy();
    expect(screen.getByRole("button", { name: /Upload image/i })).toBeTruthy();
  });

  it("cancels a request without adding its question to the session history", async () => {
    let rejectRequest: ((reason?: unknown) => void) | undefined;
    mockFetch(() => new Promise((_, reject) => { rejectRequest = reject; }));
    const { container } = render(<Workspace />);
    const textarea = await screen.findByLabelText("Ask about your selected frame");
    fireEvent.change(textarea, { target: { value: "Can you identify this unusual device?" } });
    fireEvent.click(screen.getByRole("button", { name: "Send question" }));
    const cancel = await screen.findByRole("button", { name: "Cancel" });
    fireEvent.click(cancel);
    rejectRequest?.(new DOMException("Aborted", "AbortError"));
    await waitFor(() => expect(container.querySelector(".chat-message--pending")).toBeNull());
    expect(screen.getByRole("log").textContent).not.toContain("Can you identify this unusual device?");
  });

  it("opens the summary dialog with keyboard focus and closes it with Escape", async () => {
    mockFetch();
    render(<Workspace />);
    fireEvent.click(screen.getByRole("button", { name: /Summary/i }));
    expect(await screen.findByRole("dialog")).toBeTruthy();
    await waitFor(() => expect(document.activeElement).toBe(screen.getByRole("button", { name: "Close summary" })));
    fireEvent.keyDown(window, { key: "Escape" });
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
  });

  it("ends a session, stops its camera, and keeps the summary available", async () => {
    mockFetch();
    const getUserMedia = vi.fn();
    const { track } = installCamera(getUserMedia);
    render(<Workspace />);
    fireEvent.click(screen.getByRole("button", { name: "Start camera" }));
    await screen.findByRole("button", { name: "Capture frame" });
    fireEvent.click(screen.getByRole("button", { name: /End session/i }));
    expect(track.stop).toHaveBeenCalled();
    expect(await screen.findByRole("dialog")).toBeTruthy();
    expect(document.querySelector(".task-progress b")?.textContent).toContain("0");
  });

  it("lets the user clear task progress and session history", async () => {
    mockFetch();
    render(<Workspace />);
    fireEvent.change(screen.getByLabelText("What are you setting up?"), { target: { value: "Connect a monitor" } });
    fireEvent.click(screen.getByRole("button", { name: /Identify the device and labels/i }));
    expect(document.querySelector(".task-progress b")?.textContent).toContain("1");
    fireEvent.click(screen.getByRole("button", { name: "Clear conversation" }));
    await screen.findByText("Session cleared. The camera is off.");
    expect((screen.getByLabelText("What are you setting up?") as HTMLInputElement).value).toBe("Set up a new device");
    expect(document.querySelector(".task-progress b")?.textContent).toContain("0");
  });

  it("does not allow a pending camera permission request to start after the session ends", async () => {
    mockFetch();
    let resolveStream: ((stream: MediaStream) => void) | undefined;
    const getUserMedia = vi.fn(() => new Promise((resolve) => { resolveStream = resolve; }));
    const track = { stop: vi.fn(), getSettings: () => ({ deviceId: "camera-1" }) };
    Object.defineProperty(navigator, "mediaDevices", {
      configurable: true,
      value: { getUserMedia, enumerateDevices: vi.fn(async () => []) },
    });
    Object.defineProperty(HTMLMediaElement.prototype, "play", { configurable: true, value: vi.fn(async () => undefined) });
    render(<Workspace />);
    fireEvent.click(screen.getByRole("button", { name: "Start camera" }));
    expect(getUserMedia).toHaveBeenCalledTimes(1);
    fireEvent.click(screen.getByRole("button", { name: /End session/i }));
    resolveStream?.({ getTracks: () => [track], getVideoTracks: () => [track] } as unknown as MediaStream);
    await waitFor(() => expect(track.stop).toHaveBeenCalled());
    expect(screen.getByText("CAMERA OFF")).toBeTruthy();
    expect(screen.getByRole("button", { name: /Start camera/i }).hasAttribute("disabled")).toBe(true);
  });
});
