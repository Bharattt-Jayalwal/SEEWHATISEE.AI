import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

import { POST } from "@/app/api/analyze/route";
import { GET } from "@/app/api/status/route";

afterEach(() => {
  delete process.env.OPENAI_API_KEY;
  delete process.env.OPENAI_MODEL;
  vi.unstubAllGlobals();
});

function makeRequest(body: unknown, headers: Record<string, string> = {}) {
  return new Request("http://localhost:3000/api/analyze", {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(body),
  });
}

describe("analysis route", () => {
  it("reports demo mode when no provider key is configured", async () => {
    const response = await POST(makeRequest({ question: "Which port is this?" }));
    const body = await response.json();
    expect(response.status).toBe(200);
    expect(body.mode).toBe("demo");
    expect(body.guidance.observations[0]).toMatch(/did not inspect/i);
  });

  it("validates required question text before returning demo content", async () => {
    const response = await POST(makeRequest({ question: "   " }));
    const body = await response.json();
    expect(response.status).toBe(400);
    expect(body.error.code).toBe("invalid_request");
  });

  it("rejects requests from a different origin", async () => {
    const response = await POST(makeRequest({ question: "Which port is this?" }, { origin: "https://attacker.example" }));
    expect(response.status).toBe(403);
  });

  it("rejects images with mismatched or invalid bytes in live mode", async () => {
    process.env.OPENAI_API_KEY = "test-key";
    const response = await POST(makeRequest({
      question: "Which port is this?",
      imageData: "data:image/png;base64,YWJj",
    }));
    const body = await response.json();
    expect(response.status).toBe(400);
    expect(body.error.code).toBe("invalid_image");
  });

  it("sends one selected frame to the configured Responses API and validates its output", async () => {
    process.env.OPENAI_API_KEY = "server-only-test-key";
    const guidance = {
      headline: "A connector is visible",
      observations: ["A labeled external port is visible."],
      guidance: "Compare the label with the one on your monitor.",
      nextAction: "Capture both labels in one clear frame.",
      needsClarification: false,
      unresolvedQuestion: "",
      uncertainty: "",
      safetyNote: "Do not open powered equipment.",
    };
    const fetchMock = vi.fn(async (_url: string | URL | Request, init?: RequestInit) => {
      const providerRequest = JSON.parse(String(init?.body));
      expect(providerRequest.model).toBe("gpt-6-luna");
      expect(providerRequest.store).toBe(false);
      expect(JSON.stringify(providerRequest)).toContain("data:image/png;base64,");
      return { ok: true, status: 200, json: async () => ({ output_text: JSON.stringify(guidance) }) };
    });
    vi.stubGlobal("fetch", fetchMock);
    const png = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 0]).toString("base64");
    const response = await POST(makeRequest({ imageData: `data:image/png;base64,${png}`, question: "Which port is this?" }));
    const body = await response.json();
    expect(response.status).toBe(200);
    expect(body.mode).toBe("live");
    expect(body.guidance.headline).toBe(guidance.headline);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("converts provider failures into a safe retry message", async () => {
    process.env.OPENAI_API_KEY = "server-only-test-key";
    vi.stubGlobal("fetch", vi.fn(async () => ({ ok: false, status: 429, json: async () => ({ error: "private provider details" }) })));
    const png = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 0]).toString("base64");
    const response = await POST(makeRequest({ imageData: `data:image/png;base64,${png}`, question: "Which port is this?" }));
    const body = await response.json();
    expect(response.status).toBe(429);
    expect(body.error.message).toMatch(/service is busy/i);
    expect(JSON.stringify(body)).not.toContain("private provider details");
  });

  it("does not reveal the API key through the status endpoint", async () => {
    process.env.OPENAI_API_KEY = "secret-test-value";
    const response = GET();
    const body = await response.json();
    expect(body).toEqual({ mode: "live" });
    expect(JSON.stringify(body)).not.toContain("secret-test-value");
  });

  it("rejects oversized requests before parsing the body", async () => {
    const response = await POST(new Request("http://localhost:3000/api/analyze", {
      method: "POST",
      headers: { "content-length": "9000000", "content-type": "application/json" },
      body: "{}",
    }));
    expect(response.status).toBe(413);
  });
});
